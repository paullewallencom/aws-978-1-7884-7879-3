#!/bin/bash
sudo yum install -y httpd mysql mysql-server php
sudo yum install -y php-mysql
