Chapter 1, 4, and 5 does not contains any code.

